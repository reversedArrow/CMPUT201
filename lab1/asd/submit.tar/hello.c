#include<stdio.h>

int main()
{
    printf("Hello word!\n");
    return 0;
}
